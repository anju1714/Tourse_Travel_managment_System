package com.anudip.TravelAndTurismoManagementSystem;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class UserDAO {
    private Session session;

    public UserDAO(Session session) {
        this.session = session;
    }

    public boolean usernameExists(String username) {
        String query = "SELECT COUNT(*) FROM users WHERE username = :username";
        Long count = (Long) session.createQuery(query)
                                   .setParameter("username", username)
                                   .uniqueResult();
        return count > 0;
    }

    public void insertUser(User user) {
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}
