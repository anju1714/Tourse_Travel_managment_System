package com.anudip.TravelAndTurismoManagementSystem;

import java.util.List;
import javax.persistence.*;

@Entity
public class TourDate {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    // Example of using Date for the actual tour date
    // Uncomment if needed
    // @Temporal(TemporalType.DATE)
    // private Date tourDate;

    @Column(name = "available_seats")
    private int availableSeats;

    // Many-to-One relationship with TourPackage
    @ManyToOne
    @JoinColumn(name = "tour_package_id", nullable = false)
    private TourPackage tourPackage;

    // One-to-Many relationship with Booking
    @OneToMany(mappedBy = "tourDate", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Booking> bookings;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public TourPackage getTourPackage() {
        return tourPackage;
    }

    public void setTourPackage(TourPackage tourPackage) {
        this.tourPackage = tourPackage;
    }

    public List<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }

    // Default constructor
    public TourDate() {
        super();
    }
}
