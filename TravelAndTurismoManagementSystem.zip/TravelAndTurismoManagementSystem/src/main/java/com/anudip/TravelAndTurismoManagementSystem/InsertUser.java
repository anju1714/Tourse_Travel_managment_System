package com.anudip.TravelAndTurismoManagementSystem;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Scanner;

public class InsertUser {
    public void run(Session session, Scanner scanner) {
        Transaction trx = null;
        try {
            trx = session.beginTransaction(); // Start a new transaction

            // Create a new User object
            User user = new User(); // Assuming Users is your entity class

            // Get user details from user
            System.out.print("Enter username: ");
            user.setUsername(scanner.nextLine());
            System.out.print("Enter password: ");
            user.setPassword(scanner.nextLine());
            System.out.print("Enter email: ");
            user.setEmail(scanner.nextLine());
            System.out.print("Enter phone: ");
            user.setPhone(scanner.nextLine());
            System.out.print("Enter role: ");
            user.setRole(scanner.nextLine());

            // Save the user object
            session.save(user);
            System.out.println("User inserted successfully!");

            trx.commit(); // Commit the transaction
        } catch (Exception e) {
            if (trx != null) {
                trx.rollback(); // Rollback if any error occurs
                System.out.println("Transaction rolled back.");
            }
            System.err.println("An error occurred while inserting user: " + e.getMessage());
            e.printStackTrace(); // For debugging
        }
    }
}
