package com.anudip.TravelAndTurismoManagementSystem;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        // Get the SessionFactory from HibernateUtil
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.openSession(); // Open a new session
        Scanner scanner = new Scanner(System.in); // Create a scanner for user input
        
        try {
            // Create an instance of InsertUser to handle user registration
            InsertUser insertUser = new InsertUser();
            insertUser.run(session, scanner); // Handle user registration

            // Ask if the user wants to insert hotel data
            System.out.print("Do you want to insert hotel data? (yes/no): ");
            String answer = scanner.nextLine();
            if (answer.equalsIgnoreCase("yes")) {
                // Create an instance of InsertHome to handle hotel insertion
                InsertHome insertHome = new InsertHome();
                insertHome.insertHotelData(session, scanner); // Insert hotel data
            }
        } finally {
            session.close(); // Ensure the session is closed to release resources
            scanner.close(); // Close the scanner to avoid memory leaks
        }
    }
}
