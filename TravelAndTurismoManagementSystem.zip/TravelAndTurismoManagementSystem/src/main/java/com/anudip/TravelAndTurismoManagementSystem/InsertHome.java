package com.anudip.TravelAndTurismoManagementSystem;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Scanner;

public class InsertHome {
    public void insertHotelData(Session session, Scanner scanner) {
        Transaction trx = null;
        try {
            trx = session.beginTransaction(); // Start a new transaction

            // Create a new Hotel object
            Hotel hotel = new Hotel(); // Assuming Hotel is your entity class

            // Get hotel details from user
            System.out.print("Enter hotel name: ");
            hotel.setName(scanner.nextLine()); // Assuming setName method exists
            System.out.print("Enter hotel location: ");
            hotel.setLocation(scanner.nextLine()); // Assuming setLocation method exists
            System.out.print("Enter hotel rating (1-5): ");
            hotel.setRating(Integer.parseInt(scanner.nextLine())); // Assuming setRating method exists

            // Save the hotel object
            session.save(hotel);
            System.out.println("Hotel inserted successfully!");

            trx.commit(); // Commit the transaction
        } catch (Exception e) {
            if (trx != null) {
                trx.rollback(); // Rollback if any error occurs
                System.out.println("Transaction rolled back.");
            }
            System.err.println("An error occurred while inserting hotel data: " + e.getMessage());
            e.printStackTrace(); // For debugging
        }
    }
}
